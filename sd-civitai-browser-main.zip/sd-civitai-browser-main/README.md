# sd-civitai-browser
An extension to help download models from CivitAi without leaving WebUI
